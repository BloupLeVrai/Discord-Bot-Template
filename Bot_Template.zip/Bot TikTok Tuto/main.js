const Discord = require("discord.js");

const Client = new Discord.Client

const prefix = "!";

Client.on("ready", () => {
    console.log("Bot ready");
    Client.user.setActivity("!help");
    
});

Client.on("message", message => {
    if(message.author.bot) return;

    if(message.member.hasPermission("ADMINISTRATOR")){
        if(message.content.startsWith(prefix + "ban")){
            let mention = message.mentions.members.first();

            if(mention == undefined){
                message.reply("Il y a eu un problème lors de la mention du memebre, veuillez réessayer...");
            }
            else {
                if(mention.bannable){
                    mention.ban();
                    message.channel.send("Ce membre a été banni. Clint, terminé.");
                }
                else {
                    message.reply("Ce membre est trop haut placé pour moi, je peux rien faire. Clint, terminé.")
                }
            }
        }

        
    }

    var embedHelp = new Discord.MessageEmbed()
        .setTitle("Voici de l'aide!")
        .setDescription("Inscrivez ici toutes les commandes de votre bot")
        .setColor("#f70ffa")
    

    if(message.content == prefix + "ping"){
        message.channel.send("pong")
        console.log("Commande pong utilisée")
        message.react("🏓")
    }

    if(message.content == "salut"){
        message.reply("Salut")
    }

    if(message.content == prefix + "reacttest"){
        message.react("emoji_id")
    }

    if(message.content == prefix + "help"){
        message.channel.send(embedHelp)
    }


});


Client.login("bot_token")